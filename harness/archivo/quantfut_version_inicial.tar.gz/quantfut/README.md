# QuantFut

Sistema cuantitativo de predicción de fútbol para 7 ligas. Publica picks en una
web propia y en Telegram, y corre entero en un VPS de Contabo por ~$60/mes.

Sin MARL, sin tracking data, sin Transformer. El mercado como referencia y la
infraestructura de credibilidad desde la primera línea.

---

## Estado de las fases

| Fase | Qué es | Estado | Falta |
|---|---|---|---|
| **0** Captura de cuotas | El activo del negocio | ✅ **100%** | — |
| **1** Ingesta y modelo base | Datos + Dixon-Coles | ✅ **100%** | — |
| **2** Validación y calibración | ¿Funciona de verdad? | 🟡 **55%** | Calibrador, meta-learner, baseline Elo |
| **3** Publicación y web | Lo que vendes | 🟡 **65%** | Bot receptor, frontend, cobros |
| **4** Alineaciones y GBM | Segunda generación | ❌ **0%** | Todo |
| **5** Movimiento de línea | Producto defendible | ❌ **0%** | Todo (necesita 12 meses de datos) |

### Huecos concretos que quedan

**Fase 2 — `model/calibration.py` (no existe).** Falta la capa isotónica o
Venn-ABERS que corrige las probabilidades crudas antes de compararlas con el
mercado. Es lo que hace que cuando digas 65%, gane el 65%. Sin esto el backtest
corre pero los edges que calcula no son de fiar.

**Fase 2 — el meta-learner no se ajusta.** `blend_logit()` existe en
`eval/metrics.py`, pero nada estima `w_model`. Falta la regresión logística
sobre `[logit(p_modelo), logit(p_mercado)]` en validación temporal. Prepárate
para que salga un peso bajo: es el resultado normal, no un fracaso.

**Fase 2 — falta el baseline Elo.** La puerta de avance de esta fase es "RPS
mejor que Elo simple" y no hay Elo implementado con qué compararse.

**Fase 3 — el bot de Telegram solo publica, no recibe.** Faltan `/start`,
`/track`, `/verify` y el alta de suscriptores.

**Fase 3 — falta el frontend.** El backend está completo (`/track-record`,
`/calibration`, `/chain`, `/picks/free`, `/v1/picks`); faltan las páginas.

**Fase 3 — faltan los cobros.** Webhook del procesador → alta en `subscribers`
→ invitación automática al canal privado.

---

## Arquitectura: dónde encaja cada cosa

```
  FUENTES                    VPS CONTABO                     TÚ Y TUS CLIENTES
  ───────                    ───────────                     ─────────────────

  football-data.co.uk ─┐
  FBref (scraping)    ─┤                                    ┌─ Web pública
  API-Football        ─┼──▶ workers ──▶ Postgres ──▶ API ───┼─ Canal Telegram
  The Odds API        ─┘      (cron)        │        (interna) └─ Bot
                                            │
                                            └──▶ Grafana ──────── Solo tú
```

**La API es interna.** No es un producto que vendas a terceros: es el backend
de tu propia web y de tu bot. Por eso no tiene claves por cliente, ni planes, ni
rate limiting por tier. Tiene tres niveles y nada más:

| Nivel | Auth | Para qué |
|---|---|---|
| **Público** | ninguna | Track record, calibración, cadena de hashes, picks gratis |
| **Suscriptor** | JWT (login web o Telegram) | Picks de pago, probabilidades completas |
| **Admin** | token en `.env` | Operación, disparo manual de jobs, alias |

El nivel público **no lleva auth a propósito**. Un comprador escéptico tiene que
poder auditar tu historial sin registrarse. Si le pides email para ver si eres
de fiar, no vuelve.

### Dos paneles, no uno

Son cosas distintas y conviene no mezclarlas:

**Grafana (`panel.tudominio.com`) — privado, solo tú.** Operación del sistema:
salud de la ingesta, CLV rodante, calibración, crecimiento del histórico de
cuotas, cadena de hashes. Se conecta directo a Postgres con un usuario de solo
lectura. Gratis, ya provisionado en este repo.

**Página pública de track record — tu argumento de venta.** No la hagas con
Grafana: necesita tu marca, tu dominio, tu copy y estar embebida en tu web de
ventas. Consume `/track-record`, `/calibration` y `/chain`.

La regla: Grafana sirve para mirar tu sistema, no para vender tu producto.

---

## Arranque

### Día 1 — antes que cualquier otra cosa

El worker de cuotas. Cada día que no corre es un día de datos irrecuperable, y
es el insumo del CLV, del backtest realista y del producto de fase 5.

```bash
git clone <tu-repo> && cd quantfut
cp .env.example .env && nano .env
export PG_PASSWORD='...' GRAFANA_PASSWORD='...' GRAFANA_DB_PASSWORD='...'
./scripts/setup_fase1.sh
docker compose up -d
```

`setup_fase1.sh` corre los 6 pasos en orden y **se detiene** en el paso 4 hasta
que dejes vacía la lista de nombres sin emparejar. Esa parada es intencional:
un equipo sin emparejar son partidos que el sistema nunca verá, sin dar ningún
error.

### Puertas de avance

No pases de fase sin cumplir la puerta. Es la única defensa contra construir
seis meses sobre un modelo que no funciona.

| Fase | Puerta |
|---|---|
| 0 | 7 días seguidos capturando cuotas sin intervención |
| 1 | 30 días publicando predicciones verificables sin tocar nada |
| 2 | Calibración plana en todos los deciles y RPS cerca del cierre |
| 3 | 90 días de track record público verificable |
| 4 | CLV positivo en 300+ picks |

En la fase 2, **si el backtest te da ROI de dos dígitos, hay una fuga**.
`check_leakage()` busca las tres más comunes; no encontrar nada no garantiza que
no las haya.

---

## Calendario de procesos

| Proceso | Frecuencia | Módulo |
|---|---|---|
| Captura de cuotas | cada 10 min | `qf.ingest.odds_worker` |
| Calendario de partidos | 05:15 y 17:15 | `qf.ingest.fixtures` |
| Cierre de partidos + liquidación | cada 3 h | `qf.ingest.results` |
| xG desde FBref | martes 04:00 | `qf.ingest.xg_fbref` |
| Chequeo de salud | 07:00 | `qf.ingest.health` |
| Predicciones, picks, sellado, publicación | 08:00 | `qf.publish.daily` |
| CLV de respaldo | 02:30, 10:30, 18:30 | `qf.eval.clv` |
| Resumen semanal público | lunes 09:00 | `qf.publish.weekly` |
| Verificación de la cadena | 06:00 | `qf.publish.hashchain verify` |
| Reentrenamiento | día 1 del mes | `qf.model.train` |

El job diario tiene un orden estricto: predecir → seleccionar → **sellar** →
publicar. Si el sellado falla no se publica nada ese día. Mejor no publicar que
publicar sin prueba.

---

## Lo que hace distinto a este sistema

| Pieza | Por qué está aquí |
|---|---|
| **Cadena de hashes SHA-256** | Prueba criptográfica de que no revisas predicciones. Es el producto, no un extra |
| **Triggers de inmutabilidad** | La base de datos te impide "corregir" un pick fallido aunque quieras |
| **CLV como métrica principal** | Converge en cientos de apuestas; el ROI necesita miles |
| **Shrinkage del edge (0.55)** | El edge crudo está sesgado al alza por selección adversa |
| **De-vig con Shin** | El reparto proporcional que usa todo el mundo calibra peor en underdogs |
| **Pricing en forma cerrada** | ~150 mercados por partido en 0.3 ms, sin GPU |
| **Trigger point-in-time** | La base rechaza cualquier feature con `as_of > kickoff` |
| **Emparejamiento con revisión manual** | Prefiere fallar y avisar antes que fusionar dos equipos distintos |
| **No degradar en silencio** | Un reentrenamiento peor que el activo no se despliega |

---

## La cadena de hashes en la práctica

Crea un repo público separado (`quantfut-registro-publico`), móntalo en
`CHAIN_DIR` y apunta `CHAIN_GIT_REMOTE` ahí. Cada día el sistema serializa
predicciones y picks a JSON canónico, calcula `payload_sha256`, encadena con
`chain_sha256 = sha256(prev_sha256 || payload_sha256)`, hace commit al repo
público (el timestamp de GitHub es el testigo externo) y publica los primeros
16 caracteres en Telegram.

```bash
python -m qf.publish.hashchain verify
```

Si alteras un carácter de una predicción pasada, todos los hashes posteriores
dejan de cuadrar. Eso es exactamente lo que quieres poder demostrar.

---

## Despliegue en Contabo

Contabo funciona bien, pero tiene dos particularidades: E/S de disco más lento
que Hetzner y sin backups automáticos en los planes básicos.

```bash
# Endurecer
adduser qf && usermod -aG sudo qf
sed -i 's/^#*PermitRootLogin.*/PermitRootLogin no/;
        s/^#*PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd
ufw default deny incoming && ufw allow OpenSSH && ufw allow 80,443/tcp && ufw enable
apt install -y fail2ban && systemctl enable --now fail2ban

# Swap (Contabo suele venir sin swap y Postgres lo agradece)
fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab

curl -fsSL https://get.docker.com | sh && usermod -aG docker qf

# Backups: Contabo NO los hace por ti
cat > /etc/cron.daily/qf-backup <<'EOF'
#!/bin/sh
docker compose -f /home/qf/quantfut/docker-compose.yml exec -T db \
  pg_dump -U qf quantfut | gzip > /var/backups/qf-$(date +%F).sql.gz
find /var/backups -name 'qf-*.sql.gz' -mtime +14 -delete
rclone copy /var/backups remoto:quantfut-backups
EOF
chmod +x /etc/cron.daily/qf-backup
```

Ajustes de Postgres para el disco de Contabo: `random_page_cost = 1.5`,
`effective_io_concurrency = 100`, `shared_buffers = 2GB`, `work_mem = 32MB`.

### Proxy con TLS

```
api.tudominio.com {
    reverse_proxy localhost:8000
    header Strict-Transport-Security "max-age=31536000"
}

panel.tudominio.com {
    @yo remote_ip TU.IP.FIJA.AQUI
    handle @yo { reverse_proxy localhost:3000 }
    handle { respond 404 }
}
```

Grafana queda cerrado por IP **además** del login. Es tu panel de operación: no
tiene por qué ser alcanzable desde internet.

---

## APIs y costes

| Servicio | Plan | Coste | Para qué |
|---|---|---|---|
| The Odds API | 20K créditos | $30/mes | Cuotas, Pinnacle, Betfair Exchange |
| API-Football | Básico | $19/mes | Calendario y alineaciones a T-60 |
| FBref (`soccerdata`) | — | gratis | xG histórico |
| football-data.co.uk | — | gratis | 12 años de resultados y cuotas de cierre |
| VPS Contabo | 4 vCPU / 8 GB | ~$9/mes | Todo |
| Dominio + backups | — | ~$2/mes | — |
| **Total** | | **~$60/mes** | **~$720/año** |

**The Odds API cobra en créditos, no en llamadas**: cada llamada cuesta
`n_mercados × n_regiones`. Con 7 ligas son ~2,160 créditos/mes, así que el plan
gratuito de 500 no alcanza. La región `eu` es la que trae Pinnacle y Betfair
Exchange, que son la referencia sharp de todo el sistema. Nunca la quites.

**No uses el xG de API-Football**: su cobertura es inconsistente entre ligas y
planes, y una liga sin datos devuelve un array vacío con status 200 en vez de un
error. Para xG usa FBref, que es gratis y consistente.

---

## Expectativas realistas

- Un ROI sostenido de **1-4% sobre el volumen** es un resultado profesional
  fuerte en fútbol.
- Para distinguir un ROI de 2% de cero hacen falta **miles de apuestas**. Por
  eso `summary()` devuelve siempre el intervalo de confianza bootstrap, y por
  eso el CLV va primero en todos los reportes.
- Si tu CLV medio es negativo durante 300+ picks, el modelo no tiene edge.
  Mejor saberlo en el mes 3 que en el año 2.
- Liga MX, Brasileirão y Argentina no tienen xG gratuito. El modelo ahí trabaja
  solo con goles y es menos preciso. Está en el `model-card` a propósito.

---

## Estructura

```
db/              001 esquema · 002 ligas · 003 API-Football · 004 Grafana
grafana/         provisioning + dashboard de operación
scripts/         setup_fase1.sh · bootstrap_aliases.py · crontab
src/qf/
  ingest/        odds_worker · fixtures · results · history_fd · xg_fbref · health
  model/         dixon_coles · pricing · devig · train
  publish/       daily · picks · hashchain · telegram · weekly
  eval/          clv · metrics · backtest
  api/           main (público + suscriptor + admin)
  normalize.py   emparejamiento de nombres entre fuentes
```
