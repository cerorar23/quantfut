#!/usr/bin/env bash
# Arranque ordenado de la fase 1. El orden importa: cada paso depende del anterior.
set -euo pipefail
cd "$(dirname "$0")/.."
D="docker compose exec -T worker"

echo "==> 1/6  Esquema de base de datos"
docker compose up -d db cache
sleep 8
for f in db/001_schema.sql db/002_seed_leagues.sql db/003_api_football.sql; do
  docker compose exec -T db psql -U qf -d quantfut -f "/docker-entrypoint-initdb.d/$(basename "$f")" \
    || echo "    (ya aplicado, se omite)"
done

echo "==> 2/6  Verificar los IDs de liga de API-Football"
$D python -m qf.ingest.api_football

echo "==> 3/6  Backfill historico (football-data.co.uk, ~10 min)"
$D python -m qf.ingest.history_fd

echo "==> 4/6  Emparejamiento de nombres entre fuentes"
$D python scripts/bootstrap_aliases.py
echo
echo "    DETENTE AQUI si quedaron nombres pendientes."
echo "    Corrige aliases_pendientes.csv y aplica:"
echo "      docker compose exec -T worker python scripts/bootstrap_aliases.py --fix aliases_pendientes.csv"
read -rp "    Pulsa Enter cuando la lista este vacia..."

echo "==> 5/6  Calendario y xG"
$D python -m qf.ingest.fixtures
$D python -m qf.ingest.xg_fbref

echo "==> 6/6  Entrenar el primer modelo y chequear salud"
$D python -m qf.model.train
$D python -m qf.ingest.health

echo
echo "Fase 1 completa. Arranca los workers:  docker compose up -d"
