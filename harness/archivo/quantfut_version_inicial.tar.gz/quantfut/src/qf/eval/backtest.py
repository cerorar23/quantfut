"""
Backtest walk-forward.

NUNCA uses K-fold aleatorio aquí. Entrenar con partidos de mayo para predecir
partidos de marzo produce métricas espectaculares y completamente falsas.

Protocolo:
  - Ventana expansiva, reentrenando cada `step_days`.
  - En cada paso, el modelo solo ve partidos con kickoff < corte.
  - Se compara contra el cierre sin margen del mercado.

Señal de alarma: si el backtest te da ROI de dos dígitos, NO celebres.
Busca la fuga. Las tres más comunes están listadas en check_leakage().
"""
from __future__ import annotations

import logging
from datetime import timedelta

import numpy as np
import pandas as pd

from ..config import settings
from ..model.devig import devig
from ..model.dixon_coles import DixonColes
from .metrics import evaluate

log = logging.getLogger(__name__)


def walk_forward(df: pd.DataFrame, start_date, step_days: int = 30,
                 min_train: int = 500, halflife: float = 180.0,
                 xg_blend: float = 0.65) -> dict:
    """
    df: columnas kickoff_utc, home_team, away_team, home_goals, away_goals,
        home_xg, away_xg, y opcionalmente odds_home/odds_draw/odds_away
        (cierre, para el baseline).
    """
    df = df.sort_values("kickoff_utc").reset_index(drop=True)
    cutoff = pd.Timestamp(start_date, tz="UTC")
    end = df["kickoff_utc"].max()

    model_rows, market_rows, outcomes, meta = [], [], [], []

    while cutoff < end:
        train = df[df["kickoff_utc"] < cutoff]
        nxt = cutoff + timedelta(days=step_days)
        test = df[(df["kickoff_utc"] >= cutoff) & (df["kickoff_utc"] < nxt)]

        if len(train) < min_train or test.empty:
            cutoff = nxt
            continue

        try:
            m = DixonColes(halflife_days=halflife, xg_blend=xg_blend)
            m.fit(train, as_of=cutoff.to_pydatetime())
        except Exception as exc:  # noqa: BLE001
            log.warning("Ajuste fallido en %s: %s", cutoff.date(), exc)
            cutoff = nxt
            continue

        for _, r in test.iterrows():
            pred = m.predict(r["home_team"], r["away_team"])
            p = pred["1x2"]
            model_rows.append([p["home"], p["draw"], p["away"]])

            hg, ag = int(r["home_goals"]), int(r["away_goals"])
            outcomes.append(0 if hg > ag else 1 if hg == ag else 2)

            if all(c in r and pd.notna(r[c]) for c in
                   ("odds_home", "odds_draw", "odds_away")):
                mp = devig([r["odds_home"], r["odds_draw"], r["odds_away"]],
                           settings.devig_method)
                market_rows.append(list(mp))
            else:
                market_rows.append([np.nan] * 3)

            meta.append({"kickoff": r["kickoff_utc"],
                         "known": pred["_meta"]["both_teams_known"]})

        log.info("Paso %s: train=%d test=%d", cutoff.date(), len(train), len(test))
        cutoff = nxt

    if not model_rows:
        raise RuntimeError("El backtest no produjo predicciones. Revisa min_train.")

    mp = np.array(model_rows)
    kp = np.array(market_rows)
    oc = np.array(outcomes)
    valid = ~np.isnan(kp).any(axis=1)

    res = evaluate(mp, kp[valid] if valid.any() else None,
                   oc) if not valid.any() else {}
    if valid.any():
        res = evaluate(mp[valid], kp[valid], oc[valid])
        res["n_without_market"] = int((~valid).sum())
    res["config"] = {"halflife": halflife, "xg_blend": xg_blend,
                     "step_days": step_days, "devig": settings.devig_method}
    return res


def tune_halflife(df: pd.DataFrame, start_date,
                  grid=(90, 120, 180, 250, 365)) -> dict:
    """
    Barrido de la media vida del decaimiento. Es el hiperparámetro con más
    impacto del modelo y el único que vale la pena ajustar a mano.
    """
    out = {}
    for hl in grid:
        try:
            r = walk_forward(df, start_date, halflife=float(hl))
            out[hl] = {"rps": r["rps"], "log_loss": r["log_loss"],
                       "rps_delta_vs_market": r.get("rps_delta")}
            log.info("halflife=%s -> RPS=%.5f", hl, r["rps"])
        except Exception as exc:  # noqa: BLE001
            log.warning("halflife=%s falló: %s", hl, exc)
    best = min(out, key=lambda k: out[k]["rps"]) if out else None
    return {"results": out, "best_halflife": best}


def check_leakage(df: pd.DataFrame) -> list[str]:
    """
    Las tres fugas que arruinan estos backtests, en orden de frecuencia.
    Córrelo antes de creerte cualquier resultado.
    """
    problems = []

    if "xg_recorded_at" in df.columns and "kickoff_utc" in df.columns:
        late = (pd.to_datetime(df["xg_recorded_at"]) >
                pd.to_datetime(df["kickoff_utc"]) + timedelta(hours=6)).sum()
        if late:
            problems.append(
                f"{late} partidos con xG registrado >6h tras el kickoff. "
                "Si esos valores se revisaron, tu histórico contiene información "
                "que no existía en el momento de predecir."
            )

    for c in ("odds_home", "odds_draw", "odds_away"):
        if c in df.columns and "odds_captured_at" not in df.columns:
            problems.append(
                f"La columna {c} no tiene timestamp de captura. No puedes saber "
                "si son cuotas de apertura o de cierre. Trátalas como cierre "
                "(baseline) y nunca como feature de entrenamiento."
            )
            break

    if df["kickoff_utc"].duplicated().sum() > len(df) * 0.5:
        problems.append(
            "Más de la mitad de los kickoff están duplicados exactamente. "
            "Probablemente solo tienes la fecha, no la hora. El orden temporal "
            "dentro de cada jornada será arbitrario."
        )

    if not problems:
        problems.append("Sin fugas evidentes en las comprobaciones automáticas. "
                        "Esto no garantiza que no las haya.")
    return problems
