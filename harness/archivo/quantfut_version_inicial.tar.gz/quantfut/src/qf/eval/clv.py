"""
Liquidación y CLV (Closing Line Value).

EL CLV ES TU MÉTRICA PRINCIPAL, no el P&L.

Si aconsejaste 2.10 y la línea cerró en 2.00, capturaste valor real
independientemente de si el partido se ganó. El CLV converge en cientos de
apuestas; el ROI necesita miles. Con 300 picks puedes saber si tienes edge
mirando CLV, y no puedes saberlo mirando ganancias.

Si tu CLV medio es negativo de forma sostenida, no tienes un modelo: tienes
un generador de ruido caro. Mejor saberlo en el mes 3 que en el año 2.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

import numpy as np

from ..config import settings
from ..db import execute, query
from ..model.devig import devig

log = logging.getLogger(__name__)


def _closing_prices(match_id: str, market: str, line: float | None) -> dict[str, float]:
    """Último precio antes del kickoff, preferentemente de la casa sharp."""
    rows = query(
        """SELECT DISTINCT ON (selection)
                  selection, price, bookmaker, captured_at
           FROM odds_snapshots
           WHERE match_id = %s AND market = %s
             AND (line = %s OR (%s IS NULL AND line IS NULL))
             AND mins_to_kickoff >= 0
           ORDER BY selection,
                    (bookmaker = %s) DESC,
                    captured_at DESC""",
        (match_id, market, line, line, settings.sharp_book),
    )
    return {r["selection"]: float(r["price"]) for r in rows}


def _settle_outcome(market: str, selection: str, line: float | None,
                    hg: int, ag: int) -> tuple[str, float]:
    """Devuelve (outcome, multiplicador_de_retorno_sobre_stake_a_cuota_1)."""
    diff, total = hg - ag, hg + ag

    if market == "h2h":
        winner = "home" if diff > 0 else "away" if diff < 0 else "draw"
        return ("win", 1.0) if selection == winner else ("loss", 0.0)

    if market == "btts":
        yes = hg > 0 and ag > 0
        hit = (selection == "yes") == yes
        return ("win", 1.0) if hit else ("loss", 0.0)

    if market == "double_chance":
        winner = "home" if diff > 0 else "away" if diff < 0 else "draw"
        mapping = {"1X": {"home", "draw"}, "12": {"home", "away"}, "X2": {"draw", "away"}}
        return ("win", 1.0) if winner in mapping[selection] else ("loss", 0.0)

    if market == "totals":
        if total == line:
            return ("push", 0.0)
        over = total > line
        hit = (selection == "over") == over
        return ("win", 1.0) if hit else ("loss", 0.0)

    if market.startswith("team_totals"):
        g = hg if market.endswith("home") else ag
        if g == line:
            return ("push", 0.0)
        hit = (selection == "over") == (g > line)
        return ("win", 1.0) if hit else ("loss", 0.0)

    if market == "spreads":
        adj = diff + line if selection == "home" else -diff + line
        # Líneas de cuarto: media apuesta en cada línea adyacente
        if abs(line * 2 - round(line * 2)) > 1e-9:
            a = _spread_leg(adj - 0.25)
            b = _spread_leg(adj + 0.25)
            ret = 0.5 * a + 0.5 * b
            name = ("win" if ret >= 1.0 else "half_win" if ret > 0.5
                    else "push" if ret == 0.5 else "half_loss" if ret > 0 else "loss")
            return name, ret
        if abs(adj) < 1e-9:
            return ("push", 0.0)
        return ("win", 1.0) if adj > 0 else ("loss", 0.0)

    raise ValueError(f"Mercado no liquidable: {market}")


def _spread_leg(adj: float) -> float:
    if adj > 1e-9:
        return 1.0
    if abs(adj) < 1e-9:
        return 0.5
    return 0.0


def settle_pending(lookback_hours: int = 96) -> dict:
    """Liquida picks de partidos terminados que aún no tienen resultado."""
    since = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
    rows = query(
        """SELECT p.pick_id, p.match_id, p.market, p.selection, p.line,
                  p.advised_price, p.stake_units,
                  m.home_goals, m.away_goals
           FROM picks p
           JOIN matches m USING (match_id)
           LEFT JOIN pick_results r USING (pick_id)
           WHERE r.pick_id IS NULL
             AND m.status = 'finished'
             AND m.home_goals IS NOT NULL
             AND m.kickoff_utc > %s""",
        (since,),
    )

    settled, clvs = 0, []
    for r in rows:
        try:
            outcome, ret = _settle_outcome(
                r["market"], r["selection"], r["line"],
                int(r["home_goals"]), int(r["away_goals"])
            )
        except ValueError as exc:
            log.error("No se pudo liquidar %s: %s", r["pick_id"], exc)
            continue

        stake = float(r["stake_units"])
        price = float(r["advised_price"])
        if outcome == "push":
            profit = 0.0
        else:
            profit = stake * (ret * price - 1.0)

        closing = _closing_prices(r["match_id"], r["market"], r["line"])
        clv_pct, close_prob, beat = None, None, None
        cp = closing.get(r["selection"])
        if cp:
            clv_pct = (price / cp - 1.0) * 100.0
            beat = clv_pct > 0
            clvs.append(clv_pct)
            if r["market"] == "h2h" and len(closing) == 3:
                sels = ["home", "draw", "away"]
                if all(s in closing for s in sels):
                    probs = devig([closing[s] for s in sels], settings.devig_method)
                    close_prob = float(probs[sels.index(r["selection"])])
            elif len(closing) == 2:
                sels = list(closing)
                probs = devig([closing[s] for s in sels], settings.devig_method)
                close_prob = float(probs[sels.index(r["selection"])])

        execute(
            """INSERT INTO pick_results
                 (pick_id, closing_price, closing_prob_devig, clv_pct,
                  beat_close, outcome, profit_units)
               VALUES (%s,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (pick_id) DO NOTHING""",
            (r["pick_id"], cp, close_prob, clv_pct, beat, outcome, round(profit, 4)),
        )
        settled += 1

    result = {"settled": settled,
              "avg_clv": round(float(np.mean(clvs)), 3) if clvs else None,
              "n_with_clv": len(clvs)}
    log.info("Liquidación: %s", result)
    return result


def summary(days: int = 7) -> dict:
    row = query(
        """SELECT count(*) AS n,
                  avg(r.clv_pct) AS avg_clv,
                  avg(CASE WHEN r.beat_close THEN 1.0 ELSE 0.0 END)*100 AS pct_beat,
                  sum(r.profit_units) AS profit,
                  sum(p.stake_units) AS staked
           FROM picks p JOIN pick_results r USING (pick_id)
           WHERE r.settled_at > now() - make_interval(days => %s)""",
        (days,),
    )[0]
    n = row["n"] or 0
    staked = float(row["staked"] or 0)
    profit = float(row["profit"] or 0)
    return {
        "n": n,
        "avg_clv": round(float(row["avg_clv"] or 0), 3),
        "pct_beat_close": round(float(row["pct_beat"] or 0), 1),
        "profit_units": round(profit, 2),
        "roi": round(profit / staked * 100, 2) if staked else 0.0,
        # Intervalo de confianza aproximado del ROI. Publícalo SIEMPRE:
        # sin él, cualquier ROI a 50 apuestas es una anécdota, no un resultado.
        "roi_ci95": _roi_ci(days),
    }


def _roi_ci(days: int) -> list[float] | None:
    rows = query(
        """SELECT r.profit_units, p.stake_units
           FROM picks p JOIN pick_results r USING (pick_id)
           WHERE r.settled_at > now() - make_interval(days => %s)""",
        (days,),
    )
    if len(rows) < 20:
        return None
    x = np.array([float(r["profit_units"]) for r in rows])
    s = np.array([float(r["stake_units"]) for r in rows])
    boots = [float(np.random.choice(x, len(x)).sum() / s.sum() * 100) for _ in range(2000)]
    return [round(float(np.percentile(boots, 2.5)), 2),
            round(float(np.percentile(boots, 97.5)), 2)]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    print(settle_pending())
