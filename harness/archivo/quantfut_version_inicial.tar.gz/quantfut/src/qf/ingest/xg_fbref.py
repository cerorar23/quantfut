"""
xG histórico desde FBref vía `soccerdata`. Gratis.

Por qué importa: el xG tiene bastante menos ruido que los goles, así que la
fuerza estimada converge con menos partidos. En términos de muestra efectiva
el efecto es comparable a tener 2-3 veces más partidos. Es la mayor ganancia
gratuita que tienes disponible, y sin esto el `xg_blend=0.65` del config no
hace absolutamente nada porque las columnas están vacías.

Aviso de cobertura: FBref tiene xG desde ~2017-18 para las ligas grandes y
desde fechas más tardías (o nada) para Liga MX, Brasileirão y Argentina. Esto
NO es un fallo a arreglar: es una limitación real del dato gratuito, está
documentada en el model-card, y el modelo cae automáticamente a goles donde
falta. Lo que no debes hacer es fingir que la tienes.

Es scraping, así que:
  - cachea en disco (soccerdata lo hace solo)
  - corre una vez por semana, no a diario
  - si FBref cambia su HTML, lo vas a saber por ingest_health, no por un error
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from ..db import execute, query
from ..normalize import match_team
from .api_football import record_health

log = logging.getLogger(__name__)

CACHE_DIR = "/srv/quantfut/fbref_cache"


def _seasons_for(style: str, years: int) -> list[str]:
    now = datetime.now(timezone.utc)
    if style == "european":
        start = now.year if now.month >= 7 else now.year - 1
        return [f"{y % 100:02d}{(y + 1) % 100:02d}"
                for y in range(start - years + 1, start + 1)]
    return [str(y) for y in range(now.year - years + 1, now.year + 1)]


def ingest_league(league: dict, years: int = 6) -> dict:
    try:
        import soccerdata as sd
    except ImportError:
        raise RuntimeError(
            "Falta soccerdata. Añade `soccerdata` a requirements.txt "
            "y reconstruye la imagen."
        )

    fbref_id = league.get("fbref_league_id")
    if not fbref_id:
        return {"league": league["league_id"], "skipped": "sin fbref_league_id"}

    seasons = _seasons_for(league["season_style"], years)
    try:
        fb = sd.FBref(leagues=fbref_id, seasons=seasons, data_dir=CACHE_DIR)
        df = fb.read_schedule()
    except Exception as exc:  # noqa: BLE001
        log.error("FBref %s: %s", league["league_id"], exc)
        return {"league": league["league_id"], "error": str(exc)}

    df = df.reset_index()
    cols = {c.lower(): c for c in df.columns}
    if "home_xg" not in cols or "away_xg" not in cols:
        return {"league": league["league_id"],
                "skipped": "esta liga/temporada no trae xG en FBref"}

    updated = missing = unmatched = 0

    for _, r in df.iterrows():
        hx, ax = r[cols["home_xg"]], r[cols["away_xg"]]
        if hx is None or ax is None or str(hx) == "nan" or str(ax) == "nan":
            missing += 1
            continue

        date = r[cols.get("date", "date")]
        try:
            ko_date = date.date() if hasattr(date, "date") else None
        except Exception:  # noqa: BLE001
            ko_date = None
        if ko_date is None:
            continue

        home_tid, _, hs = match_team(str(r[cols["home_team"]]), "fbref",
                                     league["league_id"])
        away_tid, _, as_ = match_team(str(r[cols["away_team"]]), "fbref",
                                      league["league_id"])
        if not home_tid or not away_tid:
            unmatched += 1
            continue

        n = execute(
            """UPDATE matches SET home_xg = %s, away_xg = %s, xg_recorded_at = now()
               WHERE league_id = %s
                 AND home_team_id = %s AND away_team_id = %s
                 AND kickoff_utc::date BETWEEN %s::date - 1 AND %s::date + 1
                 AND home_xg IS NULL""",
            (float(hx), float(ax), league["league_id"], home_tid, away_tid,
             ko_date, ko_date),
        )
        updated += n

    return {"league": league["league_id"], "updated": updated,
            "no_xg_in_source": missing, "unmatched_teams": unmatched}


def run(years: int = 6) -> dict:
    leagues = query(
        """SELECT league_id, fbref_league_id, season_style FROM leagues
           WHERE active AND fbref_league_id IS NOT NULL"""
    )
    results, total = [], 0
    for lg in leagues:
        r = ingest_league(lg, years)
        results.append(r)
        total += r.get("updated", 0)

    coverage = query(
        """SELECT league_id,
                  count(*) AS partidos,
                  count(home_xg) AS con_xg,
                  round(100.0 * count(home_xg) / NULLIF(count(*), 0), 1) AS pct
           FROM matches WHERE status = 'finished'
           GROUP BY league_id ORDER BY pct DESC NULLS LAST"""
    )
    record_health("fbref_xg", total, True, {"results": results})
    log.info("xG FBref: %d filas actualizadas", total)
    return {"total_updated": total, "per_league": results, "coverage": coverage}


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    res = run()
    print(f"\nActualizadas: {res['total_updated']} filas\n")
    print(f"{'liga':24s} {'partidos':>9s} {'con xG':>8s} {'%':>7s}")
    for c in res["coverage"]:
        print(f"{c['league_id']:24s} {c['partidos']:9d} {c['con_xg']:8d} "
              f"{c['pct'] if c['pct'] is not None else 0:6.1f}%")
    print("\nLas ligas con 0% funcionan solo con goles. Está documentado en el "
          "model-card y no es un error a arreglar.")
