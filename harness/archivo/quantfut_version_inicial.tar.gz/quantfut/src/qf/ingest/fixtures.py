"""
Calendario de partidos futuros. MÓDULO BLOQUEANTE DE LA FASE 1.

Sin esto, `matches` solo contiene partidos terminados, el odds_worker no
encuentra nada con status='scheduled' y el job diario no tiene qué predecir.

Se ejecuta 2 veces al día. Es idempotente: reingiere el mismo rango y solo
actualiza lo que cambió (reprogramaciones, cambios de horario).

Ojo con las reprogramaciones: un partido movido de fecha cambia su kickoff, y
si no lo actualizas el odds_worker captura las ventanas equivocadas y el CLV
compara contra un "cierre" que no lo era.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from ..db import execute, query, query_one
from ..normalize import resolve_or_register, slugify
from . import api_football as af

log = logging.getLogger(__name__)


def current_season(season_style: str, now: datetime | None = None) -> int:
    """
    API-Football pide `season` como año de inicio.
      - europea: 2025/26 -> 2025 (la temporada arranca en julio)
      - calendario / apertura-clausura: el año en curso
    """
    now = now or datetime.now(timezone.utc)
    if season_style == "european":
        return now.year if now.month >= 7 else now.year - 1
    return now.year


def _season_label(league: dict, ko: datetime) -> str:
    """Etiqueta de temporada para la columna `season` (consistente con el histórico)."""
    style = league["season_style"]
    if style == "european":
        y = ko.year if ko.month >= 7 else ko.year - 1
        return f"{y % 100:02d}{(y + 1) % 100:02d}"
    if style == "apertura_clausura":
        torneo = "A" if ko.month >= 7 else "C"
        return f"{ko.year}{torneo}"
    return str(ko.year)


def _build_match_id(league_id: str, season: str, home: str, away: str,
                    ko: datetime) -> str:
    return (f"{league_id}:{season}:"
            f"{slugify(home)[:12].replace(' ', '')}-"
            f"{slugify(away)[:12].replace(' ', '')}:"
            f"{ko.strftime('%Y%m%d')}")


def ingest_league(league: dict, days_ahead: int = 21) -> dict:
    now = datetime.now(timezone.utc)
    season = current_season(league["season_style"], now)

    resp, meta = af.get("fixtures", {
        "league": league["api_football_id"],
        "season": season,
        "from": now.strftime("%Y-%m-%d"),
        "to": (now + timedelta(days=days_ahead)).strftime("%Y-%m-%d"),
        "timezone": "UTC",
    })
    af.check_quota(meta)

    if meta["empty"]:
        # Silencio, no error. Puede ser parón de selecciones... o cobertura rota.
        log.warning("%s: 0 partidos en los próximos %d días (season=%s). "
                    "Verifica si es parón o si el api_football_id cambió.",
                    league["league_id"], days_ahead, season)
        return {"league": league["league_id"], "inserted": 0, "updated": 0,
                "unresolved": 0, "empty": True}

    inserted = updated = unresolved = 0

    for fx in resp:
        fixture, teams = fx["fixture"], fx["teams"]
        ko = datetime.fromisoformat(fixture["date"].replace("Z", "+00:00"))
        status = fixture["status"]["short"]

        # NS=no iniciado, TBD=por definir, PST=aplazado, CANC=cancelado
        if status in ("CANC", "ABD", "AWD", "WO"):
            continue
        db_status = "postponed" if status in ("PST", "TBD") else "scheduled"

        home_id = resolve_or_register(teams["home"]["name"], "api_football",
                                      league["league_id"])
        away_id = resolve_or_register(teams["away"]["name"], "api_football",
                                      league["league_id"])
        if not home_id or not away_id:
            unresolved += 1
            continue

        season_lbl = _season_label(league, ko)

        # ¿Ya existe por external_id? (cubre reprogramaciones que cambian la fecha)
        existing = query_one(
            """SELECT match_id, kickoff_utc, status FROM matches
               WHERE league_id = %s
                 AND external_ids ->> 'api_football' = %s""",
            (league["league_id"], str(fixture["id"])),
        )

        if existing:
            if (abs((existing["kickoff_utc"] - ko).total_seconds()) > 300
                    or existing["status"] != db_status):
                execute(
                    """UPDATE matches SET kickoff_utc = %s, status = %s
                       WHERE match_id = %s""",
                    (ko, db_status, existing["match_id"]),
                )
                # La reprogramación invalida las ventanas de cuotas ya capturadas
                execute("DELETE FROM odds_capture_log WHERE match_id = %s",
                        (existing["match_id"],))
                updated += 1
                log.info("Reprogramado %s -> %s", existing["match_id"], ko)
            continue

        home_name = query_one("SELECT canonical_name FROM teams WHERE team_id=%s",
                              (home_id,))["canonical_name"]
        away_name = query_one("SELECT canonical_name FROM teams WHERE team_id=%s",
                              (away_id,))["canonical_name"]
        match_id = _build_match_id(league["league_id"], season_lbl,
                                   home_name, away_name, ko)

        n = execute(
            """INSERT INTO matches
                 (match_id, league_id, season, kickoff_utc, home_team_id,
                  away_team_id, status, external_ids)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (match_id) DO UPDATE
                 SET kickoff_utc = EXCLUDED.kickoff_utc,
                     status = EXCLUDED.status,
                     external_ids = matches.external_ids || EXCLUDED.external_ids
               """,
            (match_id, league["league_id"], season_lbl, ko, home_id, away_id,
             db_status, f'{{"api_football": "{fixture["id"]}"}}'),
        )
        inserted += n

    return {"league": league["league_id"], "inserted": inserted,
            "updated": updated, "unresolved": unresolved, "empty": False}


def run(days_ahead: int = 21) -> dict:
    leagues = query(
        """SELECT league_id, name, country, api_football_id, season_style
           FROM leagues WHERE active AND api_football_id IS NOT NULL"""
    )
    results, total, problems = [], 0, []

    for lg in leagues:
        try:
            r = ingest_league(lg, days_ahead)
        except Exception as exc:  # noqa: BLE001
            log.error("Fallo en %s: %s", lg["league_id"], exc)
            problems.append(f"{lg['league_id']}: {exc}")
            continue
        results.append(r)
        total += r["inserted"] + r["updated"]
        if r["unresolved"]:
            problems.append(f"{r['league']}: {r['unresolved']} equipos sin emparejar")

    ok = not problems
    af.record_health("fixtures", total, ok, {"results": results, "problems": problems})

    if problems:
        from ..publish.telegram import alert
        alert("Ingesta de calendario con incidencias:\n" + "\n".join(problems[:8]))

    summary = {"total": total, "leagues": len(results), "problems": problems}
    log.info("Calendario: %s", summary)
    return summary


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    print(run())
