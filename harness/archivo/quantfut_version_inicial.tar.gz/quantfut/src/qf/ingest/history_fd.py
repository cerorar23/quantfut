"""
Ingesta del histórico de football-data.co.uk (gratis, ~25 años).

Es la base estadística sobre la que se entrena el modelo de fuerza. Incluye
resultados, tiros, córners, tarjetas y cuotas de varias casas por partido.

Dos familias de archivos:
  - Principales (E0, SP1, I1, D1, F1, N1, P1, T1, G1, SC0...): columnas ricas,
    incluidas cuotas de cierre de varias casas.
  - "Extra" (MEX, ARG, BRA, USA...): menos columnas, sin datos de tiros.
    Liga MX vive aquí. Ténlo en cuenta: para esas ligas el modelo trabaja con
    goles, no con xG ni tiros, y debe ponderarse peor en el meta-learner.
"""
from __future__ import annotations

import io
import logging
from datetime import datetime, timezone

import httpx
import pandas as pd

from ..db import execute, query_one
from ..normalize import resolve_team, slugify

log = logging.getLogger(__name__)

BASE_MAIN = "https://www.football-data.co.uk/mmz4281/{season}/{code}.csv"
BASE_EXTRA = "https://www.football-data.co.uk/new/{code}.csv"

# Cuotas de cierre por casa: prioridad para el baseline de mercado
CLOSING_COLS = [
    ("PSCH", "PSCD", "PSCA", "pinnacle"),
    ("B365CH", "B365CD", "B365CA", "bet365"),
    ("MaxCH", "MaxCD", "MaxCA", "market_max"),
    ("AvgCH", "AvgCD", "AvgCA", "market_avg"),
    ("PSH", "PSD", "PSA", "pinnacle"),
    ("B365H", "B365D", "B365A", "bet365"),
    ("AvgH", "AvgD", "AvgA", "market_avg"),
]


def _fetch_csv(url: str) -> pd.DataFrame | None:
    try:
        with httpx.Client(timeout=60, follow_redirects=True) as c:
            r = c.get(url)
            r.raise_for_status()
        return pd.read_csv(io.BytesIO(r.content), encoding="latin-1",
                           on_bad_lines="skip")
    except Exception as exc:  # noqa: BLE001
        log.warning("No se pudo descargar %s: %s", url, exc)
        return None


def _parse_date(row) -> datetime | None:
    d = str(row.get("Date", "")).strip()
    t = str(row.get("Time", "")).strip()
    for fmt in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(d, fmt)
            break
        except ValueError:
            continue
    else:
        return None
    if t and ":" in t:
        try:
            hh, mm = t.split(":")[:2]
            dt = dt.replace(hour=int(hh), minute=int(mm))
        except ValueError:
            dt = dt.replace(hour=19)
    else:
        # Sin hora: se marca a las 19:00 UTC. El backtest debe saber que el
        # orden intra-jornada es arbitrario (ver check_leakage).
        dt = dt.replace(hour=19)
    return dt.replace(tzinfo=timezone.utc)


def _ensure_team(league_id: str, raw_name: str) -> int | None:
    canonical = resolve_team(raw_name, "football_data")
    if canonical is None:
        canonical = raw_name.strip()
        execute(
            """INSERT INTO teams (league_id, canonical_name) VALUES (%s, %s)
               ON CONFLICT (league_id, canonical_name) DO NOTHING""",
            (league_id, canonical),
        )
        execute(
            """INSERT INTO team_aliases (alias, source, team_id)
               SELECT %s, 'football_data', team_id FROM teams
               WHERE league_id = %s AND canonical_name = %s
               ON CONFLICT DO NOTHING""",
            (raw_name.strip(), league_id, canonical),
        )
    row = query_one(
        "SELECT team_id FROM teams WHERE league_id = %s AND canonical_name = %s",
        (league_id, canonical),
    )
    return row["team_id"] if row else None


def ingest_season(league_id: str, fd_code: str, season: str,
                  extra: bool = False) -> int:
    url = (BASE_EXTRA.format(code=fd_code) if extra
           else BASE_MAIN.format(season=season, code=fd_code))
    df = _fetch_csv(url)
    if df is None or df.empty:
        return 0

    if extra and "Season" in df.columns:
        df = df[df["Season"].astype(str).str.contains(season[:4], na=False)]

    inserted = 0
    for _, row in df.iterrows():
        home_raw, away_raw = row.get("HomeTeam"), row.get("AwayTeam")
        if not isinstance(home_raw, str) or not isinstance(away_raw, str):
            continue
        ko = _parse_date(row)
        if ko is None:
            continue

        hid = _ensure_team(league_id, home_raw)
        aid = _ensure_team(league_id, away_raw)
        if not hid or not aid:
            continue

        match_id = (f"{league_id}:{season}:"
                    f"{slugify(home_raw)[:12].replace(' ', '')}-"
                    f"{slugify(away_raw)[:12].replace(' ', '')}:"
                    f"{ko.strftime('%Y%m%d')}")

        def _n(col, cast=int):
            v = row.get(col)
            try:
                return cast(v) if pd.notna(v) else None
            except (ValueError, TypeError):
                return None

        execute(
            """INSERT INTO matches
                 (match_id, league_id, season, kickoff_utc, home_team_id,
                  away_team_id, status, home_goals, away_goals,
                  home_goals_ht, away_goals_ht, home_shots, away_shots,
                  home_shots_target, away_shots_target, home_corners, away_corners,
                  result_recorded_at)
               VALUES (%s,%s,%s,%s,%s,%s,'finished',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (match_id) DO NOTHING""",
            (match_id, league_id, season, ko, hid, aid,
             _n("FTHG"), _n("FTAG"), _n("HTHG"), _n("HTAG"),
             _n("HS"), _n("AS"), _n("HST"), _n("AST"),
             _n("HC"), _n("AC"), ko),
        )

        # Cuotas históricas -> snapshots marcados como cierre
        for ch, cd, ca, book in CLOSING_COLS:
            if all(c in row and pd.notna(row[c]) for c in (ch, cd, ca)):
                for sel, col in (("home", ch), ("draw", cd), ("away", ca)):
                    try:
                        price = float(row[col])
                    except (ValueError, TypeError):
                        continue
                    if price <= 1.0:
                        continue
                    execute(
                        """INSERT INTO odds_snapshots
                             (match_id, bookmaker, market, selection, line, price,
                              captured_at, mins_to_kickoff, window_tag, source)
                           VALUES (%s,%s,'h2h',%s,NULL,%s,%s,0,'close','football_data')""",
                        (match_id, book, sel, price, ko),
                    )
                break  # solo la primera familia de columnas disponible

        inserted += 1

    log.info("%s %s: %d partidos", league_id, season, inserted)
    return inserted


def backfill(seasons: list[str] | None = None) -> dict:
    """Carga inicial. Ejecutar una vez al montar el sistema."""
    from ..db import query

    seasons = seasons or [f"{y % 100:02d}{(y + 1) % 100:02d}" for y in range(2014, 2026)]
    leagues = query("SELECT league_id, fd_code, fd_extra FROM leagues "
                    "WHERE fd_code IS NOT NULL AND active")
    total = {}
    for lg in leagues:
        n = 0
        if lg["fd_extra"]:
            n += ingest_season(lg["league_id"], lg["fd_code"], seasons[-1], extra=True)
        else:
            for s in seasons:
                n += ingest_season(lg["league_id"], lg["fd_code"], s)
        total[lg["league_id"]] = n
    return total


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print(backfill())
