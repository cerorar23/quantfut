"""
API interna. NO es un producto que vendas a terceros.

Es el backend de tu propio frontend web y de tu bot de Telegram. Eso cambia el
diseño respecto a una API comercial: no hay claves por cliente, no hay planes,
no hay rate limiting por tier. Hay tres niveles de acceso y nada más:

  PÚBLICO      Sin auth. Track record, calibración, cadena de hashes y los
               picks gratuitos. Es tu escaparate: un comprador escéptico tiene
               que poder auditarte sin registrarse. Si le pides email para ver
               tu historial, asume que no vuelve.

  SUSCRIPTOR   JWT emitido al iniciar sesión en tu web o al vincular Telegram.
               Acceso a los picks de pago y a las probabilidades completas.

  ADMIN        Token único en .env, solo tú. Operación del sistema.
               Rutas separadas para poder cerrarlas por IP en el proxy.

Todo se sirve desde Redis, precalculado. La API nunca ejecuta el modelo en la
ruta de la petición: latencia de milisegundos y un pico de tráfico desde
Telegram no tumba el VPS.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from datetime import datetime, timedelta, timezone

import jwt
import redis
from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from ..config import settings
from ..db import execute, query, query_one
from ..eval.clv import summary

JWT_SECRET = os.getenv("JWT_SECRET") or secrets.token_hex(32)
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
DOMAIN = os.getenv("DOMAIN", "localhost")
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")

app = FastAPI(
    title="QuantFut",
    version=settings.model_version,
    description="Probabilidades calibradas de fútbol. No es asesoría financiera.",
    docs_url=None, redoc_url=None,   # sin docs públicas: es una API interna
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[f"https://{DOMAIN}", f"https://www.{DOMAIN}",
                   "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

r = redis.from_url(settings.redis_url, decode_responses=True)

publico = APIRouter(tags=["público"])
privado = APIRouter(prefix="/v1", tags=["suscriptor"])
admin = APIRouter(prefix="/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Autenticación
# ---------------------------------------------------------------------------

def issue_token(subscriber_id: int, tier: str, days: int = 30) -> str:
    return jwt.encode(
        {"sub": str(subscriber_id), "tier": tier,
         "exp": datetime.now(timezone.utc) + timedelta(days=days)},
        JWT_SECRET, algorithm="HS256",
    )


def current_subscriber(authorization: str = Header(default="")) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Inicia sesión para ver los picks")
    try:
        payload = jwt.decode(authorization[7:], JWT_SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Tu sesión expiró, vuelve a iniciar sesión")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Sesión inválida")

    sub = query_one(
        """SELECT subscriber_id, tier, status, valid_until FROM subscribers
           WHERE subscriber_id = %s""",
        (int(payload["sub"]),),
    )
    if not sub or sub["status"] != "active":
        raise HTTPException(403, "Suscripción inactiva")
    if sub["valid_until"] and sub["valid_until"] < datetime.now(timezone.utc):
        raise HTTPException(403, "Tu suscripción venció")
    return sub


def require_admin(x_admin_token: str = Header(default="")) -> bool:
    if not ADMIN_TOKEN or not hmac.compare_digest(x_admin_token, ADMIN_TOKEN):
        raise HTTPException(404)   # 404, no 401: no confirmes que la ruta existe
    return True


# ---------------------------------------------------------------------------
# PÚBLICO — el escaparate. Sin auth, a propósito.
# ---------------------------------------------------------------------------

@publico.get("/health")
def health():
    return {"status": "ok", "model_version": settings.model_version}


@publico.get("/track-record")
def track_record():
    """
    Se publica entero, incluidos los meses en pérdida. Ocultar las rachas malas
    es lo que hace que nadie crea a nadie en este sector.
    """
    return {
        "mensual": query("SELECT * FROM v_track_record"),
        "ultimos_7d": summary(7),
        "ultimos_30d": summary(30),
        "ultimo_ano": summary(365),
        "nota": ("El CLV mide si tomamos mejor precio que el cierre del mercado "
                 "y es nuestra métrica principal. El ROI a pocos cientos de "
                 "picks es ruido estadístico, por eso publicamos su intervalo "
                 "de confianza al lado."),
    }


@publico.get("/calibration")
def calibration():
    return {"runs": query(
        """SELECT model_version, window_start, window_end, n_obs,
                  rps, rps_market, log_loss, brier, bins, created_at
           FROM calibration_runs ORDER BY created_at DESC LIMIT 12"""
    )}


@publico.get("/chain")
def chain(limit: int = Query(90, le=365)):
    return {
        "lotes": query(
            """SELECT batch_date, n_predictions, n_picks, payload_sha256,
                      prev_sha256, chain_sha256, created_at, published_ref
               FROM prediction_batches ORDER BY seq DESC LIMIT %s""",
            (limit,),
        ),
        "como_verificar": [
            "1. Descarga el JSON del lote del repo público.",
            "2. Calcula su SHA-256 y compáralo con payload_sha256.",
            "3. Comprueba que sha256(prev_sha256 || payload_sha256) == chain_sha256.",
            "Si cambiáramos una sola predicción pasada, todos los hashes "
            "posteriores dejarían de cuadrar.",
        ],
    }


@publico.get("/model-card")
def model_card():
    art = query_one("SELECT model_version, trained_at, params, val_metrics "
                    "FROM model_artifacts WHERE is_active LIMIT 1")
    return {
        "model_version": settings.model_version,
        "artefacto": art,
        "metodo": "Dixon-Coles con decaimiento temporal, objetivo mezclado goles/xG",
        "eliminacion_de_margen": settings.devig_method,
        "limitaciones_conocidas": [
            "Liga MX, Brasileirão y Argentina no tienen xG en las fuentes "
            "gratuitas; ahí el modelo trabaja solo con goles y es menos preciso.",
            "Equipos con menos de 15 partidos de historia se marcan como "
            "confianza baja y no generan picks.",
            "Esta versión no incorpora alineaciones confirmadas.",
            f"El edge mostrado lleva un factor de encogimiento de "
            f"{settings.edge_shrinkage}: el edge crudo es sistemáticamente "
            "optimista por selección adversa.",
        ],
    }


@publico.get("/picks/free")
def picks_gratis():
    """Los picks del canal gratuito. Mismo dato que Telegram, para la web."""
    return _picks(("free",))


# ---------------------------------------------------------------------------
# SUSCRIPTOR
# ---------------------------------------------------------------------------

@privado.post("/auth/telegram")
def auth_telegram(payload: dict):
    """
    Login con el widget de Telegram. Verifica la firma HMAC contra el token del
    bot; sin esto cualquiera podría enviar un telegram_id ajeno.
    """
    data = dict(payload)
    received = data.pop("hash", "")
    check = "\n".join(f"{k}={data[k]}" for k in sorted(data))
    secret = hashlib.sha256(settings.tg_bot_token.encode()).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected, received):
        raise HTTPException(401, "Firma de Telegram inválida")
    if time.time() - int(data.get("auth_date", 0)) > 86400:
        raise HTTPException(401, "Enlace de acceso caducado")

    tg_id = int(data["id"])
    sub = query_one("SELECT subscriber_id, tier FROM subscribers "
                    "WHERE telegram_id = %s", (tg_id,))
    if not sub:
        execute(
            """INSERT INTO subscribers (telegram_id, tier, meta)
               VALUES (%s, 'free', %s)
               ON CONFLICT (telegram_id) DO NOTHING""",
            (tg_id, json.dumps({"username": data.get("username")})),
        )
        sub = query_one("SELECT subscriber_id, tier FROM subscribers "
                        "WHERE telegram_id = %s", (tg_id,))

    return {"token": issue_token(sub["subscriber_id"], sub["tier"]),
            "tier": sub["tier"]}


@privado.get("/picks")
def picks(sub=Depends(current_subscriber)):
    tiers = ("free",) if sub["tier"] == "free" else ("free", "paid")
    return _picks(tiers)


@privado.get("/matches/{match_id}/predictions")
def predictions(match_id: str, sub=Depends(current_subscriber)):
    cached = r.get(f"pred:{match_id}:{sub['tier']}")
    if cached:
        return json.loads(cached)

    row = query_one(
        """SELECT prediction_id, match_id, model_version, generated_at,
                  home_lambda, away_lambda, markets, market_consensus,
                  confidence_tier, data_completeness
           FROM predictions WHERE match_id = %s
           ORDER BY generated_at DESC LIMIT 1""",
        (match_id,),
    )
    if not row:
        raise HTTPException(404, "Todavía no hay predicción para ese partido")

    if sub["tier"] == "free":
        row["markets"] = {
            "1x2": row["markets"].get("1x2"),
            "totals": {"2.5": row["markets"].get("totals", {}).get("2.5")},
        }

    r.setex(f"pred:{match_id}:{sub['tier']}", 600, json.dumps(row, default=str))
    return row


@privado.get("/fixtures")
def fixtures(league: str | None = None, hours: int = Query(72, le=240),
             sub=Depends(current_subscriber)):
    return query(
        """SELECT m.match_id, m.league_id, m.kickoff_utc,
                  th.canonical_name AS local, ta.canonical_name AS visitante,
                  EXISTS(SELECT 1 FROM predictions p
                         WHERE p.match_id = m.match_id) AS tiene_prediccion
           FROM matches m
           JOIN teams th ON th.team_id = m.home_team_id
           JOIN teams ta ON ta.team_id = m.away_team_id
           WHERE m.status = 'scheduled'
             AND (%s IS NULL OR m.league_id = %s)
             AND m.kickoff_utc BETWEEN now() AND now() + make_interval(hours => %s)
           ORDER BY m.kickoff_utc""",
        (league, league, hours),
    )


def _picks(tiers: tuple[str, ...]) -> list[dict]:
    return query(
        """SELECT p.pick_id, p.match_id, p.market, p.selection, p.line,
                  p.model_prob, p.advised_price, p.bookmaker, p.edge_pct,
                  p.stake_units, p.tier, p.published_at,
                  m.kickoff_utc, m.league_id,
                  th.canonical_name AS local, ta.canonical_name AS visitante
           FROM picks p
           JOIN matches m USING (match_id)
           JOIN teams th ON th.team_id = m.home_team_id
           JOIN teams ta ON ta.team_id = m.away_team_id
           WHERE m.kickoff_utc > now() AND p.tier = ANY(%s)
           ORDER BY p.edge_pct DESC""",
        (list(tiers),),
    )


# ---------------------------------------------------------------------------
# ADMIN — operación. Ciérralo por IP en el proxy además del token.
# ---------------------------------------------------------------------------

@admin.get("/health", dependencies=[Depends(require_admin)])
def admin_health():
    from ..ingest.health import run as health_run
    return health_run(alert_on_fail=False)


@admin.get("/unresolved", dependencies=[Depends(require_admin)])
def unresolved():
    from ..normalize import pending_report
    return pending_report()


@admin.post("/alias", dependencies=[Depends(require_admin)])
def add_alias(payload: dict):
    from ..normalize import register_alias
    t = query_one(
        "SELECT team_id FROM teams WHERE league_id=%s AND canonical_name=%s",
        (payload["league_id"], payload["canonical_name"]),
    )
    if not t:
        raise HTTPException(404, "Ese equipo no existe en esa liga")
    register_alias(payload["raw_name"], payload["source"], t["team_id"])
    return {"ok": True}


@admin.post("/run/{job}", dependencies=[Depends(require_admin)])
def run_job(job: str):
    """Disparo manual de los jobs. Útil para depurar sin entrar por SSH."""
    jobs = {
        "fixtures": ("..ingest.fixtures", "run"),
        "results": ("..ingest.results", "close_recent"),
        "odds": ("..ingest.odds_worker", "run_once"),
        "xg": ("..ingest.xg_fbref", "run"),
        "daily": ("..publish.daily", "run"),
        "settle": ("..eval.clv", "settle_pending"),
    }
    if job not in jobs:
        raise HTTPException(404, f"Jobs disponibles: {', '.join(jobs)}")
    import importlib
    mod = importlib.import_module(jobs[job][0], package=__package__)
    return getattr(mod, jobs[job][1])()


@admin.get("/picks/pending", dependencies=[Depends(require_admin)])
def pending_settlement():
    return query(
        """SELECT p.pick_id, p.match_id, p.market, p.selection, p.advised_price,
                  m.kickoff_utc, m.status
           FROM picks p JOIN matches m USING (match_id)
           LEFT JOIN pick_results res USING (pick_id)
           WHERE res.pick_id IS NULL AND m.kickoff_utc < now()
           ORDER BY m.kickoff_utc"""
    )


app.include_router(publico)
app.include_router(privado)
app.include_router(admin)

if os.path.isdir(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(os.path.join(STATIC_DIR, "track.html"))
