"""Configuración central. Todo por variables de entorno, nada hardcodeado."""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()


def _f(key: str, default: float) -> float:
    return float(os.getenv(key, default))


def _i(key: str, default: int) -> int:
    return int(os.getenv(key, default))


@dataclass(frozen=True)
class Settings:
    # --- Infraestructura ---
    pg_dsn: str = os.getenv("PG_DSN", "postgresql://qf:qf@localhost:5432/quantfut")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    # --- APIs ---
    odds_api_key: str = os.getenv("ODDS_API_KEY", "")
    odds_api_base: str = "https://api.the-odds-api.com/v4"
    odds_api_regions: str = os.getenv("ODDS_API_REGIONS", "eu,us")
    odds_api_markets: str = os.getenv("ODDS_API_MARKETS", "h2h,totals,spreads")
    api_football_key: str = os.getenv("API_FOOTBALL_KEY", "")

    # --- Telegram ---
    tg_bot_token: str = os.getenv("TG_BOT_TOKEN", "")
    tg_channel_free: str = os.getenv("TG_CHANNEL_FREE", "")
    tg_channel_paid: str = os.getenv("TG_CHANNEL_PAID", "")
    tg_alert_chat: str = os.getenv("TG_ALERT_CHAT", "")  # alertas de fallos

    # --- Publicación de la cadena de hashes ---
    chain_dir: str = os.getenv("CHAIN_DIR", "/srv/quantfut/chain")
    chain_git_remote: str = os.getenv("CHAIN_GIT_REMOTE", "")

    # --- Modelo ---
    model_version: str = os.getenv("MODEL_VERSION", "0.1.0")
    fs_version: str = os.getenv("FS_VERSION", "fs-0.1.0")
    artifact_dir: str = os.getenv("ARTIFACT_DIR", "/srv/quantfut/artifacts")

    # Media vida del decaimiento temporal, en días.
    # 180 = un partido de hace 6 meses pesa la mitad que uno de hoy.
    decay_halflife_days: float = _f("DECAY_HALFLIFE_DAYS", 180.0)
    # Mezcla goles/xG para el objetivo del modelo de fuerza. 0 = solo goles, 1 = solo xG.
    xg_blend: float = _f("XG_BLEND", 0.65)
    max_goals_matrix: int = _i("MAX_GOALS_MATRIX", 12)

    # --- Gestión de riesgo ---
    # El edge estimado está sesgado al alza por selección adversa:
    # solo apuestas donde el modelo discrepa, que es donde suele equivocarse.
    edge_shrinkage: float = _f("EDGE_SHRINKAGE", 0.55)
    min_edge_pct: float = _f("MIN_EDGE_PCT", 3.0)       # tras shrinkage
    kelly_fraction: float = _f("KELLY_FRACTION", 0.20)
    max_stake_units: float = _f("MAX_STAKE_UNITS", 2.0)  # tope duro por apuesta
    max_picks_per_day: int = _i("MAX_PICKS_PER_DAY", 12)

    # Casa de referencia para el precio "justo" y para el CLV.
    sharp_book: str = os.getenv("SHARP_BOOK", "pinnacle")
    # Método de eliminación de margen: shin | power | additive | multiplicative
    devig_method: str = os.getenv("DEVIG_METHOD", "shin")

    # --- Captura de cuotas ---
    # Ventanas objetivo en minutos antes del kickoff. Solo se llama a la API
    # cuando un partido entra en una ventana aún no capturada (ahorro de cuota).
    odds_windows: tuple = field(default=(
        ("t72", 4320, 4200),
        ("t24", 1440, 1380),
        ("t6",   360,  330),
        ("t1",    60,   50),
        ("close", 12,    3),
    ))


settings = Settings()
