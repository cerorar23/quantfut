"""
Entrenamiento mensual y registro de artefactos.

Dos protecciones importantes:

1. NO SE DESPLIEGA UN MODELO QUE EMPEORA. El nuevo artefacto solo se marca
   activo si su RPS en validación es igual o mejor que el del activo actual.
   Sin esto, un reentrenamiento con datos corruptos te degrada en silencio.

2. HASH DEL DATASET. Cada artefacto guarda el SHA-256 del dataset con el que
   se entrenó. Es lo que te permite reproducir y hacer rollback.

Este es también el único punto del stack que justifica GPU: si migras a un
modelo jerárquico bayesiano (numpyro/JAX), el muestreo NUTS pasa de horas en
CPU a minutos en GPU. Mide primero en el VPS antes de pagar Colab.
"""
from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from ..config import settings
from ..db import execute, query, query_one
from ..eval.backtest import walk_forward
from .dixon_coles import DixonColes

log = logging.getLogger(__name__)


def load_training_data(league_id: str | None = None,
                       years: int = 12) -> pd.DataFrame:
    since = datetime.now(timezone.utc) - timedelta(days=365 * years)
    rows = query(
        """SELECT m.match_id, m.league_id, m.kickoff_utc,
                  th.canonical_name AS home_team, ta.canonical_name AS away_team,
                  m.home_goals, m.away_goals, m.home_xg, m.away_xg,
                  oh.price AS odds_home, od.price AS odds_draw, oa.price AS odds_away
           FROM matches m
           JOIN teams th ON th.team_id = m.home_team_id
           JOIN teams ta ON ta.team_id = m.away_team_id
           LEFT JOIN v_closing_odds oh ON oh.match_id = m.match_id
                AND oh.market='h2h' AND oh.selection='home' AND oh.bookmaker=%s
           LEFT JOIN v_closing_odds od ON od.match_id = m.match_id
                AND od.market='h2h' AND od.selection='draw' AND od.bookmaker=%s
           LEFT JOIN v_closing_odds oa ON oa.match_id = m.match_id
                AND oa.market='h2h' AND oa.selection='away' AND oa.bookmaker=%s
           WHERE m.status='finished' AND m.home_goals IS NOT NULL
             AND m.kickoff_utc > %s
             AND (%s IS NULL OR m.league_id = %s)
           ORDER BY m.kickoff_utc""",
        (settings.sharp_book, settings.sharp_book, settings.sharp_book,
         since, league_id, league_id),
    )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["kickoff_utc"] = pd.to_datetime(df["kickoff_utc"], utc=True)
    return df


def dataset_hash(df: pd.DataFrame) -> str:
    key = df[["match_id", "home_goals", "away_goals"]].to_csv(index=False)
    return hashlib.sha256(key.encode()).hexdigest()


def train_and_register(new_version: str | None = None,
                       validation_days: int = 365) -> dict:
    df = load_training_data()
    if df.empty:
        raise RuntimeError("Sin datos de entrenamiento. Ejecuta la ingesta histórica.")

    version = new_version or datetime.now(timezone.utc).strftime("%Y.%m.%d")
    ds_hash = dataset_hash(df)

    # Validación walk-forward sobre el último año antes de desplegar nada
    val_start = df["kickoff_utc"].max() - timedelta(days=validation_days)
    val = walk_forward(df, val_start,
                       halflife=settings.decay_halflife_days,
                       xg_blend=settings.xg_blend)
    log.info("Validación: RPS=%.5f (mercado %.5f) n=%d",
             val["rps"], val.get("rps_market", float("nan")), val["n_obs"])

    # Comparación con el modelo activo. Nunca degradar en silencio.
    active = query_one("SELECT model_version, val_metrics FROM model_artifacts "
                       "WHERE is_active LIMIT 1")
    if active:
        prev_rps = json.loads(json.dumps(active["val_metrics"])).get("rps")
        if prev_rps is not None and val["rps"] > prev_rps * 1.005:
            msg = (f"El nuevo modelo empeora ({val['rps']:.5f} vs {prev_rps:.5f}). "
                   "No se activa. Revisa la ingesta de datos.")
            log.error(msg)
            from ..publish.telegram import alert
            alert(msg)
            return {"version": version, "activated": False, "reason": msg,
                    "val": val}

    # Ajuste final sobre TODO el histórico
    model = DixonColes(halflife_days=settings.decay_halflife_days,
                       xg_blend=settings.xg_blend)
    model.fit(df)

    Path(settings.artifact_dir).mkdir(parents=True, exist_ok=True)
    path = f"{settings.artifact_dir}/dc_{version}.pkl"
    model.save(path)

    execute("UPDATE model_artifacts SET is_active = FALSE WHERE is_active")
    execute(
        """INSERT INTO model_artifacts
             (model_version, trained_at, dataset_sha256, params, val_metrics,
              artifact_uri, is_active)
           VALUES (%s, now(), %s, %s, %s, %s, TRUE)
           ON CONFLICT (model_version) DO UPDATE
             SET trained_at = now(), val_metrics = EXCLUDED.val_metrics,
                 is_active = TRUE""",
        (version, ds_hash,
         json.dumps({"halflife": settings.decay_halflife_days,
                     "xg_blend": settings.xg_blend,
                     "home_adv": model.params.home_adv,
                     "rho": model.params.rho,
                     "n_teams": len(model.params.teams)}),
         json.dumps(val), path),
    )

    # Registro de calibración para el dashboard público
    execute(
        """INSERT INTO calibration_runs
             (model_version, window_start, window_end, market, n_obs,
              rps, log_loss, brier, rps_market, bins)
           VALUES (%s, %s, %s, '1x2', %s, %s, %s, %s, %s, %s)""",
        (version, val_start.date(), df["kickoff_utc"].max().date(),
         val["n_obs"], val["rps"], val["log_loss"], val["brier"],
         val.get("rps_market"), json.dumps(val["bins"])),
    )

    log.info("Modelo %s activado (%d partidos)", version, len(df))
    return {"version": version, "activated": True, "n_matches": len(df),
            "dataset_sha256": ds_hash, "val": val}


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    print(json.dumps(train_and_register(), indent=2, default=str))
