"""
Dixon-Coles con decaimiento temporal y objetivo mezclado goles/xG.

Diferencias frente al Dixon-Coles de libro (1997), todas orientadas a
eficiencia de muestra:

1. Decaimiento exponencial en lugar de ventana fija: un partido de hace
   6 meses pesa la mitad que uno de hoy (media vida configurable).
2. Objetivo mezclado goles/xG. El xG tiene menos ruido que los goles, así que
   la fuerza estimada converge con menos partidos. Se usa cuasi-verosimilitud
   de Poisson, que admite objetivos continuos.
3. Ventaja de local estimada, no fijada.
4. Encogimiento hacia la media de liga (ridge) para equipos con pocos partidos,
   que es el problema real de los recién ascendidos.

NOTA: este es el modelo de Fase 1. El upgrade natural es un modelo jerárquico
bayesiano (PyMC/numpyro) con pooling parcial entre ligas, que además te da
incertidumbre por equipo. Es lo único de este stack que justifica GPU.
"""
from __future__ import annotations

import json
import math
import pickle
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

import numpy as np
from scipy.optimize import minimize

from .pricing import price_all_markets


@dataclass
class DCParams:
    teams: list[str]
    attack: list[float]
    defence: list[float]
    home_adv: float
    rho: float
    halflife_days: float
    xg_blend: float
    ridge: float
    fitted_at: str
    n_matches: int
    league_id: str | None = None

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)


class DixonColes:
    def __init__(self, halflife_days: float = 180.0, xg_blend: float = 0.65,
                 ridge: float = 0.02, max_goals: int = 12):
        self.halflife = halflife_days
        self.xg_blend = xg_blend
        self.ridge = ridge
        self.max_goals = max_goals
        self.params: DCParams | None = None
        self._idx: dict[str, int] = {}

    # ---------------- entrenamiento ----------------

    def _weights(self, kickoffs: np.ndarray, as_of: datetime) -> np.ndarray:
        days = np.array([(as_of - k).total_seconds() / 86400.0 for k in kickoffs])
        xi = math.log(2.0) / self.halflife
        return np.exp(-xi * np.clip(days, 0, None))

    def fit(self, df, as_of: datetime | None = None, league_id: str | None = None):
        """
        df: DataFrame con columnas
            kickoff_utc, home_team, away_team, home_goals, away_goals,
            home_xg, away_xg  (xG puede ser NaN; entonces cae a goles)
        """
        as_of = as_of or datetime.now(timezone.utc)
        df = df.dropna(subset=["home_goals", "away_goals"]).copy()
        if len(df) < 100:
            raise ValueError(f"Muestra insuficiente para ajustar: {len(df)} partidos")

        teams = sorted(set(df["home_team"]) | set(df["away_team"]))
        self._idx = {t: i for i, t in enumerate(teams)}
        n = len(teams)

        hi = df["home_team"].map(self._idx).to_numpy()
        ai = df["away_team"].map(self._idx).to_numpy()
        hg = df["home_goals"].to_numpy(dtype=float)
        ag = df["away_goals"].to_numpy(dtype=float)

        # Objetivo mezclado. Si falta xG, se usa el gol.
        hx = df.get("home_xg", np.nan)
        ax = df.get("away_xg", np.nan)
        hx = np.asarray(hx, dtype=float) if hx is not None else np.full(len(df), np.nan)
        ax = np.asarray(ax, dtype=float) if ax is not None else np.full(len(df), np.nan)
        b = self.xg_blend
        y_h = np.where(np.isnan(hx), hg, (1 - b) * hg + b * hx)
        y_a = np.where(np.isnan(ax), ag, (1 - b) * ag + b * ax)

        w = self._weights(df["kickoff_utc"].to_numpy(), as_of)
        w = w / w.mean()

        hg_i, ag_i = hg.astype(int), ag.astype(int)

        def nll(p: np.ndarray) -> float:
            atk, dfn = p[:n], p[n:2 * n]
            ha, rho = p[-2], np.clip(p[-1], -0.25, 0.25)

            lam = np.exp(atk[hi] - dfn[ai] + ha)
            mu = np.exp(atk[ai] - dfn[hi])
            lam = np.clip(lam, 1e-6, 25.0)
            mu = np.clip(mu, 1e-6, 25.0)

            # Cuasi-verosimilitud de Poisson (válida con objetivo continuo;
            # equivale a Poisson salvo constante cuando y es entero)
            ll = y_h * np.log(lam) - lam + y_a * np.log(mu) - mu
            # La corrección tau se evalúa sobre los goles REALES (enteros)
            ll = ll + np.log(np.clip(_tau_vec(hg_i, ag_i, lam, mu, rho), 1e-9, None))

            penalty = (self.ridge * (np.sum(atk ** 2) + np.sum(dfn ** 2))
                       + 1000.0 * atk.mean() ** 2 + 1000.0 * dfn.mean() ** 2)
            return float(-np.sum(w * ll) + penalty)

        x0 = np.concatenate([np.zeros(n), np.zeros(n), [0.25], [-0.03]])
        bounds = [(-2.5, 2.5)] * (2 * n) + [(-0.5, 1.0), (-0.25, 0.25)]
        res = minimize(nll, x0, method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": 800, "maxfun": 120000})

        p = res.x
        self.params = DCParams(
            teams=teams,
            attack=p[:n].tolist(),
            defence=p[n:2 * n].tolist(),
            home_adv=float(p[-2]),
            rho=float(np.clip(p[-1], -0.25, 0.25)),
            halflife_days=self.halflife,
            xg_blend=self.xg_blend,
            ridge=self.ridge,
            fitted_at=as_of.isoformat(),
            n_matches=int(len(df)),
            league_id=league_id,
        )
        return self

    # ---------------- inferencia ----------------

    def lambdas(self, home_team: str, away_team: str) -> tuple[float, float]:
        if self.params is None:
            raise RuntimeError("Modelo no entrenado")
        p = self.params
        # Equipo desconocido (recién ascendido, sin historia): cae a la media de liga
        hi = self._idx.get(home_team)
        ai = self._idx.get(away_team)
        atk_h = p.attack[hi] if hi is not None else 0.0
        dfn_h = p.defence[hi] if hi is not None else 0.0
        atk_a = p.attack[ai] if ai is not None else 0.0
        dfn_a = p.defence[ai] if ai is not None else 0.0
        lam = math.exp(atk_h - dfn_a + p.home_adv)
        mu = math.exp(atk_a - dfn_h)
        return min(lam, 6.0), min(mu, 6.0)

    def predict(self, home_team: str, away_team: str) -> dict:
        lam, mu = self.lambdas(home_team, away_team)
        markets = price_all_markets(lam, mu, self.params.rho, self.max_goals)
        known = home_team in self._idx and away_team in self._idx
        markets["_meta"] = {
            "home_lambda": lam, "away_lambda": mu,
            "rho": self.params.rho,
            "both_teams_known": known,
        }
        return markets

    # ---------------- persistencia ----------------

    def save(self, path: str) -> None:
        with open(path, "wb") as f:
            pickle.dump({"params": asdict(self.params), "idx": self._idx,
                         "halflife": self.halflife, "xg_blend": self.xg_blend,
                         "ridge": self.ridge, "max_goals": self.max_goals}, f)

    @classmethod
    def load(cls, path: str) -> "DixonColes":
        with open(path, "rb") as f:
            d = pickle.load(f)
        m = cls(d["halflife"], d["xg_blend"], d["ridge"], d["max_goals"])
        m.params = DCParams(**d["params"])
        m._idx = d["idx"]
        return m


def _tau_vec(hg, ag, lam, mu, rho):
    """tau vectorizado con lambda/mu por partido."""
    t = np.ones_like(lam, dtype=float)
    m00 = (hg == 0) & (ag == 0)
    m01 = (hg == 0) & (ag == 1)
    m10 = (hg == 1) & (ag == 0)
    m11 = (hg == 1) & (ag == 1)
    t = np.where(m00, 1.0 - lam * mu * rho, t)
    t = np.where(m01, 1.0 + lam * rho, t)
    t = np.where(m10, 1.0 + mu * rho, t)
    t = np.where(m11, 1.0 - rho, t)
    return t
