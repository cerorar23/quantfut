"""
Selección de picks: de probabilidades del modelo a apuestas publicables.

Tres protecciones que casi nadie implementa y que son la diferencia entre un
track record real y uno que se derrumba:

1. SHRINKAGE DEL EDGE. Solo apuestas donde discrepas del mercado, que es
   justo donde tu modelo tiende a equivocarse (selección adversa). El edge
   crudo está sesgado al alza. Se multiplica por un factor < 1 antes de Kelly.

2. KELLY FRACCIONAL CON TOPE DURO. Kelly completo quiebra con errores de
   estimación. 0.20K más un tope de 2 unidades por apuesta.

3. DESCORRELACIÓN. Máximo un pick por partido. Kelly asume apuestas
   independientes y 20 picks de la misma jornada con el mismo sesgo de modelo
   no lo son.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np

from ..config import settings
from ..db import query
from ..model.devig import consensus_devig, devig

log = logging.getLogger(__name__)


@dataclass
class Candidate:
    match_id: str
    prediction_id: str
    market: str
    selection: str
    line: float | None
    model_prob: float
    best_price: float
    best_book: str
    market_prob: float
    raw_edge: float
    shrunk_edge: float
    stake_units: float
    kickoff_utc: object
    label: str


def kelly(prob: float, price: float, fraction: float, cap: float) -> float:
    """Kelly fraccional sobre cuota decimal. b = price - 1."""
    b = price - 1.0
    if b <= 0:
        return 0.0
    f = (prob * b - (1.0 - prob)) / b
    return float(np.clip(f * fraction, 0.0, cap))


def _best_prices(match_id: str) -> dict[tuple[str, str, float | None], tuple[float, str]]:
    """Mejor cuota disponible por (mercado, selección, línea) en el snapshot más reciente."""
    rows = query(
        """SELECT DISTINCT ON (bookmaker, market, selection, line)
                  bookmaker, market, selection, line, price
           FROM odds_snapshots
           WHERE match_id = %s
           ORDER BY bookmaker, market, selection, line, captured_at DESC""",
        (match_id,),
    )
    best: dict = {}
    for r in rows:
        k = (r["market"], r["selection"], r["line"])
        if k not in best or r["price"] > best[k][0]:
            best[k] = (float(r["price"]), r["bookmaker"])
    return best


def _market_consensus_1x2(match_id: str) -> dict[str, float]:
    rows = query(
        """SELECT DISTINCT ON (bookmaker, selection)
                  bookmaker, selection, price
           FROM odds_snapshots
           WHERE match_id = %s AND market = 'h2h'
           ORDER BY bookmaker, selection, captured_at DESC""",
        (match_id,),
    )
    quotes: dict[str, dict[str, float]] = {}
    for r in rows:
        quotes.setdefault(r["bookmaker"], {})[r["selection"]] = float(r["price"])
    quotes = {b: q for b, q in quotes.items() if set(q) == {"home", "draw", "away"}}
    return consensus_devig(quotes, settings.devig_method, settings.sharp_book)


def find_candidates(prediction: dict) -> list[Candidate]:
    """
    prediction: fila de la tabla predictions, con markets (JSONB) desempaquetado.
    Devuelve candidatos ordenados por edge, ya filtrados por umbral.
    """
    from ..model.pricing import flatten_for_edge

    match_id = prediction["match_id"]
    best = _best_prices(match_id)
    if not best:
        return []

    consensus = _market_consensus_1x2(match_id)
    out: list[Candidate] = []

    for market, selection, line, model_p in flatten_for_edge(prediction["markets"]):
        key = (market, selection, line)
        if key not in best or model_p <= 0.02 or model_p >= 0.98:
            continue
        price, book = best[key]

        raw_edge = (model_p * price - 1.0) * 100.0
        if raw_edge <= 0:
            continue

        shrunk_edge = raw_edge * settings.edge_shrinkage
        if shrunk_edge < settings.min_edge_pct:
            continue

        # Probabilidad implícita del mercado para este resultado (referencia y auditoría)
        if market == "h2h" and consensus:
            mkt_p = consensus.get(selection, 1.0 / price)
        else:
            mkt_p = 1.0 / price

        # Kelly sobre la probabilidad ENCOGIDA, no sobre la cruda.
        p_shrunk = (shrunk_edge / 100.0 + 1.0) / price
        stake = kelly(p_shrunk, price, settings.kelly_fraction, settings.max_stake_units)
        if stake <= 0.05:
            continue

        line_txt = "" if line is None else f" {line:+g}"
        out.append(Candidate(
            match_id=match_id,
            prediction_id=str(prediction["prediction_id"]),
            market=market, selection=selection, line=line,
            model_prob=float(model_p), best_price=price, best_book=book,
            market_prob=float(mkt_p),
            raw_edge=raw_edge, shrunk_edge=shrunk_edge,
            stake_units=round(stake, 2),
            kickoff_utc=prediction.get("kickoff_utc"),
            label=f"{market}{line_txt} {selection}",
        ))

    out.sort(key=lambda c: -c.shrunk_edge)
    return out


def select_daily(predictions: list[dict]) -> list[Candidate]:
    """
    Aplica descorrelación y tope diario:
      - máximo 1 pick por partido (el de mayor edge)
      - máximo N picks por día
    """
    per_match: dict[str, Candidate] = {}
    for pred in predictions:
        for c in find_candidates(pred):
            cur = per_match.get(c.match_id)
            if cur is None or c.shrunk_edge > cur.shrunk_edge:
                per_match[c.match_id] = c

    picks = sorted(per_match.values(), key=lambda c: -c.shrunk_edge)
    picks = picks[: settings.max_picks_per_day]

    total = sum(p.stake_units for p in picks)
    if total > 10.0:  # exposición diaria máxima: 10 unidades
        scale = 10.0 / total
        for p in picks:
            p.stake_units = round(p.stake_units * scale, 2)
        log.info("Exposición escalada x%.2f (total era %.1f u)", scale, total)

    return picks


def persist(picks: list[Candidate], tier: str = "paid") -> int:
    from ..db import executemany
    rows = [
        (p.prediction_id, p.match_id, p.market, p.selection, p.line,
         p.model_prob, p.best_price, p.best_book,
         round(p.shrunk_edge, 3), round(p.raw_edge, 3), p.stake_units, tier)
        for p in picks
    ]
    return executemany(
        """INSERT INTO picks
             (prediction_id, match_id, market, selection, line, model_prob,
              advised_price, bookmaker, edge_pct, raw_edge_pct, stake_units, tier)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        rows,
    )
