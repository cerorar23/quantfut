"""
Orquestador diario. Es el único proceso que publica al mundo.

Orden ESTRICTO, no negociable:
  1. Generar predicciones (INSERT inmutable)
  2. Seleccionar picks (INSERT inmutable)
  3. SELLAR la cadena de hashes
  4. Solo entonces publicar en Telegram/web

Si publicas antes de sellar, el hash deja de probar nada. Si el paso 3 falla,
el 4 no se ejecuta: mejor no publicar hoy que publicar sin prueba.

Cron sugerido: 08:00 hora local, antes del primer kickoff europeo.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone

from ..config import settings
from ..db import query, query_one
from ..model.dixon_coles import DixonColes
from ..model.devig import consensus_devig
from . import picks as pk
from . import telegram as tg
from .hashchain import seal

log = logging.getLogger(__name__)


def _upcoming(hours: int = 36) -> list[dict]:
    return query(
        """SELECT m.match_id, m.league_id, m.kickoff_utc,
                  th.canonical_name AS home_team, ta.canonical_name AS away_team,
                  (SELECT count(*) FROM matches x
                   WHERE x.status='finished'
                     AND (x.home_team_id = m.home_team_id OR x.away_team_id = m.home_team_id)
                  ) AS home_history,
                  (SELECT count(*) FROM matches x
                   WHERE x.status='finished'
                     AND (x.home_team_id = m.away_team_id OR x.away_team_id = m.away_team_id)
                  ) AS away_history
           FROM matches m
           JOIN teams th ON th.team_id = m.home_team_id
           JOIN teams ta ON ta.team_id = m.away_team_id
           WHERE m.status = 'scheduled'
             AND m.kickoff_utc BETWEEN now() AND now() + make_interval(hours => %s)
           ORDER BY m.kickoff_utc""",
        (hours,),
    )


def _confidence(home_hist: int, away_hist: int, has_odds: bool) -> str:
    """Comunicar cuándo el modelo sabe poco es señal de seriedad, no de debilidad."""
    if not has_odds:
        return "low"
    if min(home_hist, away_hist) < 15:
        return "low"
    if min(home_hist, away_hist) < 40:
        return "medium"
    return "high"


def _consensus(match_id: str) -> dict:
    rows = query(
        """SELECT DISTINCT ON (bookmaker, selection) bookmaker, selection, price
           FROM odds_snapshots WHERE match_id = %s AND market = 'h2h'
           ORDER BY bookmaker, selection, captured_at DESC""",
        (match_id,),
    )
    q: dict[str, dict[str, float]] = {}
    for r in rows:
        q.setdefault(r["bookmaker"], {})[r["selection"]] = float(r["price"])
    q = {b: v for b, v in q.items() if set(v) == {"home", "draw", "away"}}
    return consensus_devig(q, settings.devig_method, settings.sharp_book)


def generate_predictions(model_path: str | None = None) -> list[dict]:
    from ..db import conn

    model_path = model_path or f"{settings.artifact_dir}/dc_{settings.model_version}.pkl"
    model = DixonColes.load(model_path)

    matches = _upcoming()
    out: list[dict] = []

    for m in matches:
        try:
            markets = model.predict(m["home_team"], m["away_team"])
        except Exception as exc:  # noqa: BLE001
            log.error("Predicción fallida %s: %s", m["match_id"], exc)
            continue

        meta = markets.pop("_meta")
        cons = _consensus(m["match_id"])
        tier = _confidence(int(m["home_history"]), int(m["away_history"]), bool(cons))

        with conn() as c, c.cursor() as cur:
            cur.execute(
                """INSERT INTO predictions
                     (match_id, model_version, fs_version, home_lambda,
                      away_lambda, rho, markets, market_consensus,
                      confidence_tier, data_completeness)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   RETURNING prediction_id""",
                (m["match_id"], settings.model_version, settings.fs_version,
                 meta["home_lambda"], meta["away_lambda"], meta["rho"],
                 json.dumps(markets), json.dumps(cons), tier,
                 json.dumps({"home_history": int(m["home_history"]),
                             "away_history": int(m["away_history"]),
                             "both_teams_known": meta["both_teams_known"],
                             "bookmakers_seen": len(cons)})),
            )
            pid = cur.fetchone()["prediction_id"]

        out.append({"prediction_id": pid, "match_id": m["match_id"],
                    "markets": markets, "kickoff_utc": m["kickoff_utc"],
                    "confidence_tier": tier,
                    "teams": (m["home_team"], m["away_team"])})

    log.info("Predicciones generadas: %d", len(out))
    return out


def run() -> dict:
    preds = generate_predictions()
    if not preds:
        tg.alert("El job diario no generó ninguna predicción. Revisa la ingesta.")
        return {"predictions": 0}

    # Los partidos de confianza baja no se convierten en picks publicables.
    eligible = [p for p in preds if p["confidence_tier"] != "low"]
    selected = pk.select_daily(eligible)
    pk.persist(selected, tier="paid")

    receipt = seal()
    if not receipt:
        tg.alert("FALLO AL SELLAR LA CADENA. No se publicó nada hoy.")
        return {"predictions": len(preds), "picks": len(selected), "sealed": False}

    team_names = {p["match_id"]: p["teams"] for p in preds}
    published = tg.publish_batch(selected, team_names, receipt["chain_sha256"])

    result = {"predictions": len(preds), "eligible": len(eligible),
              "picks": len(selected), "chain": receipt["chain_sha256"][:16],
              **published}
    log.info("Job diario: %s", result)
    return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s %(message)s")
    print(run())
